package libraryman;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class LibrarianTableModel extends AbstractTableModel {
    private List<Librarian> librarians;
    private String[] columnNames = { "name", "password", "email", "adress1", "city", "contact" }; // Add column names as needed

    public LibrarianTableModel(List<Librarian> librarians) {
        this.librarians = librarians;
        
    }

    @Override
    public int getRowCount() {
        return librarians.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Librarian librarian = librarians.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return librarian.getname(); // Name
            case 1:
                return librarian.getpassword(); // Password
            case 2:
                return librarian.getemail(); // Email
            case 3:
                return librarian.getadress1(); // Adress1
            case 4:
                return librarian.getcity(); // City
            case 5:
                return librarian.getcontact(); // Contact
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
      ///  System.out.println("Row: " + rowIndex + ", Column: " + columnIndex + ", Value: " + getValueAt(rowIndex, columnIndex));

    }
    
}
